import unittest
from app import app, match_scheme

class SchemeApiTests(unittest.TestCase):
    def setUp(self):
        self.client=app.test_client()

    def test_health_and_catalog(self):
        self.assertEqual(self.client.get('/api/health').status_code,200)
        data=self.client.get('/api/schemes?page_size=50').get_json()
        self.assertEqual(data['total'],10)
        self.assertTrue(all(x['verification_status']=='unverified' for x in data['items']))

    def test_search_uses_scheme_names(self):
        data=self.client.get('/api/schemes?q=INSPIRE').get_json()
        self.assertEqual(data['total'],1)
        self.assertIn('INSPIRE',data['items'][0]['scheme_name'])

    def test_incomplete_unverified_record_needs_verification(self):
        data=self.client.post('/api/eligibility/match',json={'profile':{'age':22}}).get_json()
        self.assertEqual(len(data['results']),10)
        self.assertTrue(all(x['status']=='needs_verification' for x in data['results']))
        self.assertTrue(all(x['unknown_criteria'] for x in data['results']))

    def test_invalid_profile_rejected(self):
        self.assertEqual(self.client.post('/api/eligibility/match',json={'profile':{'age':121}}).status_code,400)
        self.assertEqual(self.client.post('/api/eligibility/match',json={'profile':{'aadhaar':'123'}}).status_code,400)

    def test_chat_fallback_without_llm(self):
        data=self.client.post('/api/chat',json={'question':'Show INSPIRE scholarship'}).get_json()
        self.assertEqual(data['mode'],'dataset_search')
        self.assertFalse(data['llm_available'])
        self.assertTrue(data['schemes'])

    def test_income_boundary_basis_and_state_rule(self):
        scheme={'id':'synthetic-test-only','scheme_name':'Synthetic test scheme','verification_status':'verified','eligibility_rules':{'income_limit_inr':400000,'applicable_states':['Karnataka']}}
        matched=match_scheme(scheme,{'annual_family_income_inr':400000,'income_type':'Family / household','state':'Karnataka'})
        self.assertEqual(matched['status'],'likely_eligible')
        self.assertEqual(match_scheme(scheme,{'annual_family_income_inr':400001,'income_type':'Family / household','state':'Karnataka'})['status'],'not_currently_matched')
        self.assertEqual(match_scheme(scheme,{'annual_family_income_inr':200000,'income_type':'Individual','state':'Karnataka'})['status'],'possibly_eligible')
        self.assertEqual(match_scheme(scheme,{'annual_family_income_inr':200000,'income_type':'Family / household','state':'Kerala'})['status'],'not_currently_matched')

    def test_unverified_record_rules_are_not_applied(self):
        scheme={'id':'synthetic-test-only','scheme_name':'Synthetic test scheme','verification_status':'unverified','eligibility_rules':{'minimum_age':90}}
        result=match_scheme(scheme,{'age':18})
        self.assertEqual(result['status'],'needs_verification')
        self.assertEqual(result['failed_mandatory_criteria'],[])

    def test_verified_rule_boundaries_and_missing_profile(self):
        scheme={'id':'synthetic-test-only','scheme_name':'Synthetic test scheme','verification_status':'verified','eligibility_rules':{'minimum_age':18,'maximum_age':30}}
        self.assertEqual(match_scheme(scheme,{'age':18})['status'],'likely_eligible')
        self.assertEqual(match_scheme(scheme,{'age':31})['status'],'not_currently_matched')
        self.assertEqual(match_scheme(scheme,{})['status'],'possibly_eligible')

if __name__=='__main__': unittest.main()

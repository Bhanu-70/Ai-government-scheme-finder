import React, { useEffect, useState } from "react";
import { api } from "./api.js";
const Eyebrow = ({ children, light = false }) => (
    <div className={"eyebrow " + (light ? "light" : "")}>
      <i />
      {children}
    </div>
  ),
  Arrow = () => <span aria-hidden="true">↗</span>,
  Notice = ({
    children = "Preliminary guidance only. Government departments make final eligibility decisions.",
  }) => <div className="notice">ⓘ　{children}</div>,
  Pill = () => <span className="pill">● Needs verification</span>;
function Brand({ go }) {
  return (
    <button className="brand" onClick={() => go("home")}>
      <b className="brand-mark">
        <i />
        <i />
        <i />
      </b>
      <span>
        scheme<span className="orange">setu</span>
        <small>PUBLIC BENEFITS, MADE CLEAR</small>
      </span>
    </button>
  );
}
class ShaderBoundary extends React.Component {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="hero-glow" />
    ) : (
      this.props.children
    );
  }
}
function ShaderBackdrop() {
  const [s, setS] = useState(null);
  useEffect(() => {
    if (
      matchMedia("(prefers-reduced-motion: reduce)").matches ||
      !("gpu" in navigator)
    )
      return;
    let live = true;
    import("shaders/react")
      .then(({ Shader, LinearGradient, CursorTrail }) => {
        if (live) setS({ Shader, LinearGradient, CursorTrail });
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);
  if (!s?.Shader || !s?.LinearGradient) return <div className="hero-glow" />;
  const { Shader, LinearGradient, CursorTrail } = s;
  return (
    <ShaderBoundary>
      <div className="shader-layer" aria-hidden="true">
        <Shader className="shader-canvas">
          <LinearGradient colorA="#102a43" colorB="#176b78" />
          {CursorTrail && <CursorTrail />}
        </Shader>
      </div>
    </ShaderBoundary>
  );
}
function Header({ page, go }) {
  const [o, setO] = useState(false);
  const nav = (p) => {
    go(p);
    setO(false);
    scrollTo({ top: 0, behavior: "smooth" });
  };
  return (
    <header className="header">
      <div className="header-inner">
        <Brand go={nav} />
        <button
          className="menu-toggle"
          onClick={() => setO(!o)}
          aria-label="Toggle navigation"
        >
          ☰
        </button>
        <nav className={o ? "nav open" : "nav"}>
          <button onClick={() => nav("explore")}>Explore schemes</button>
          <button onClick={() => nav("match")}>Check eligibility</button>
          <button onClick={() => nav("assistant")}>Scheme Assistant</button>
          <button className="nav-cta" onClick={() => nav("match")}>
            Find my schemes <Arrow />
          </button>
        </nav>
      </div>
    </header>
  );
}
function Footer({ go }) {
  return (
    <footer>
      <div className="footer-main wrap">
        <div>
          <Brand go={go} />
          <p>
            Clearer paths to public support. Explore what’s known and what still
            needs checking.
          </p>
        </div>
        <div>
          <b>DISCOVER</b>
          <button onClick={() => go("explore")}>Explore schemes</button>
          <button onClick={() => go("match")}>Check eligibility</button>
          <button onClick={() => go("assistant")}>Scheme Assistant</button>
        </div>
        <div>
          <b>OUR STANDARD</b>
          <p>Confirm requirements with the official department.</p>
          <a
            href="https://www.myscheme.gov.in/"
            target="_blank"
            rel="noreferrer"
          >
            myScheme.gov.in ↗
          </a>
        </div>
      </div>
      <div className="footer-bottom wrap">
        <span>© SchemeSetu · Built for informed discovery</span>
        <span>Preliminary information only · No profile data is stored</span>
      </div>
    </footer>
  );
}
function Home({ go, count }) {
  return (
    <>
      <section className="hero">
        <ShaderBackdrop />
        <div className="hero-grid" />
        <div className="hero-copy wrap">
          <Eyebrow light>PUBLIC BENEFITS, MADE CLEAR</Eyebrow>
          <h1>
            Find Government Schemes
            <br />
            <em>Made for You.</em>
          </h1>
          <p>
            Explore government scheme information in one place. Understand
            what’s known, what’s missing, and where to verify details.
          </p>
          <div className="actions">
            <button className="btn saffron" onClick={() => go("match")}>
              Find my schemes <Arrow />
            </button>
            <button className="btn glass" onClick={() => go("explore")}>
              Explore all schemes
            </button>
          </div>
          <div className="hero-points">
            <span>◇ Privacy-first profile</span>
            <span>⌖ Clear match explanations</span>
            <span>◎ Official sources, where available</span>
          </div>
        </div>
        <div className="hero-stamp">
          <span>योजना</span>
          <b>for all</b>
          <small>INDIA · SUPPORT · FOR EVERYONE</small>
        </div>
      </section>
      <section className="trust">
        <div className="wrap trust-grid">
          <div>
            <i>◇</i>
            <span>
              <b>Built around transparency</b>
              <small>See what is verified and what needs a closer look.</small>
            </span>
          </div>
          <div>
            <i>✳</i>
            <span>
              <b>Your information stays yours</b>
              <small>Profile details are only used for a match request.</small>
            </span>
          </div>
          <div>
            <i>◎</i>
            <span>
              <b>Official sources come first</b>
              <small>Go to the department for final requirements.</small>
            </span>
          </div>
        </div>
      </section>
      <section className="section wrap">
        <div className="section-head">
          <div>
            <Eyebrow>HOW IT WORKS</Eyebrow>
            <h2>A clearer way to get started.</h2>
          </div>
          <p>
            Start with a few details or browse the available scheme records.
          </p>
        </div>
        <div className="steps">
          {[
            [
              "01",
              "Tell us what matters",
              "Share only details you’re comfortable using for a preliminary match.",
            ],
            [
              "02",
              "See what may fit",
              "Review criteria, including gaps and information still needed.",
            ],
            [
              "03",
              "Verify before applying",
              "Confirm requirements with the responsible government department.",
            ],
          ].map((x) => (
            <article key={x[0]}>
              <span>{x[0]}</span>
              <i>✳</i>
              <h3>{x[1]}</h3>
              <p>{x[2]}</p>
            </article>
          ))}
        </div>
      </section>
      <section className="category-band">
        <div className="wrap">
          <div className="section-head">
            <div>
              <Eyebrow>AREAS OF SUPPORT</Eyebrow>
              <h2>Explore by what you need.</h2>
            </div>
            <button className="text-btn" onClick={() => go("explore")}>
              Browse scheme names <Arrow />
            </button>
          </div>
          <div className="categories">
            {[
              ["Education & scholarships", "▤"],
              ["Farmers & agriculture", "❋"],
              ["Women & families", "♡"],
              ["Work & enterprise", "⌁"],
              ["Health & housing", "◇"],
              ["Pensions & assistance", "◎"],
            ].map((x) => (
              <button key={x[0]} onClick={() => go("explore")}>
                <i>{x[1]}</i>
                <span>
                  {x[0]}
                  <small>Explore available records</small>
                </span>
                <b>→</b>
              </button>
            ))}
          </div>
        </div>
      </section>
      <section className="feature wrap">
        <div>
          <Eyebrow>A TOOL FOR YOUR NEXT STEP</Eyebrow>
          <h2>
            Know what’s known.
            <br />
            <em>Know what to check.</em>
          </h2>
          <p>
            SchemeSetu explains its sources and the limits of each record, so
            you can take the next step with clearer expectations.
          </p>
          <button className="btn navy" onClick={() => go("explore")}>
            Explore scheme records <Arrow />
          </button>
        </div>
        <div className="feature-card">
          <div className="fc-head">
            <i>▤</i>
            <span>
              <b>Scheme information</b>
              <small>A transparent record</small>
            </span>
            <Pill />
          </div>
          <b className="rule">
            What can be checked <i>✓</i>
          </b>
          <p>Published conditions — when a source provides them.</p>
          <b className="rule warn">
            What needs confirmation <i>ⓘ</i>
          </b>
          <p>Details not included or not verified by an official source.</p>
          <div className="fc-foot">
            Official requirements <b>→</b>
          </div>
        </div>
      </section>
      <section className="closing">
        <div className="wrap closing-inner">
          <div>
            <Eyebrow light>START WITH WHAT YOU KNOW</Eyebrow>
            <h2>
              There’s a next step
              <br />
              for every question.
            </h2>
          </div>
          <div>
            <p>
              Browse names or try a profile-based match. Review your information
              before submitting.
            </p>
            <button className="btn saffron" onClick={() => go("match")}>
              Check my options <Arrow />
            </button>
          </div>
        </div>
      </section>
      <div className="source-note wrap">
        <b>ⓘ</b>
        <p>
          <strong>About the current catalog.</strong> The workbook lists scheme
          names and profile/outcome rows, but no official descriptions, rules,
          benefits, or application links. Records are unverified; outcome labels
          are not used. {count} names are available.
        </p>
      </div>
    </>
  );
}
function SchemeCard({ s, details, saved, toggle }) {
  return (
    <article className="scheme-card">
      <div className="card-top">
        <span className="category">▤ Scholarships & fellowships</span>
        <button
          className={"save " + (saved ? "saved" : "")}
          onClick={() => toggle(s.id)}
          aria-label="Save scheme"
        >
          {saved ? "♥" : "♡"}
        </button>
      </div>
      <h3>{s.scheme_name}</h3>
      <div className="card-meta">
        <span>◎ {s.government_level || "Government level not recorded"}</span>
        <Pill />
      </div>
      <p>
        {s.description ||
          "The source workbook contains a scheme name only. Official overview and requirements have not yet been added."}
      </p>
      <div className="missing">
        ⓘ Official eligibility, benefits, and application details are not
        available in this record.
      </div>
      <div className="card-foot">
        <button className="text-btn" onClick={() => details(s.id)}>
          View details <Arrow />
        </button>
        <span>No official link listed</span>
      </div>
    </article>
  );
}
function Details({ s, close }) {
  useEffect(() => {
    const f = (e) => e.key === "Escape" && close();
    addEventListener("keydown", f);
    return () => removeEventListener("keydown", f);
  }, [close]);
  if (!s) return null;
  return (
    <div
      className="modal"
      onMouseDown={(e) => e.target === e.currentTarget && close()}
    >
      <section role="dialog" aria-modal="true" aria-labelledby="detail-title">
        <button className="modal-close" onClick={close} aria-label="Close">
          ×
        </button>
        <Eyebrow>SCHEME RECORD</Eyebrow>
        <h2 id="detail-title">{s.scheme_name}</h2>
        <Pill />
        <Notice>
          This record has not been checked against an official source.
        </Notice>
        <h3>Overview</h3>
        <p>
          {s.description ||
            "No official overview is available in the provided workbook."}
        </p>
        <h3>Eligibility information</h3>
        <p>
          {s.other_eligibility_conditions ||
            "No verified eligibility conditions are available. Missing requirements are not evidence of eligibility or ineligibility."}
        </p>
        <div className="detail-cols">
          <div>
            <h3>Benefits</h3>
            <p>{s.benefits || "Not present in the workbook."}</p>
          </div>
          <div>
            <h3>Documents & application</h3>
            <p>Not listed in the workbook.</p>
          </div>
        </div>
        <h3>Source and verification</h3>
        <p>
          Recorded source: {s.source_name || "Not recorded"}. Last verified:{" "}
          {s.last_verified_date || "Not verified"}.
        </p>
        {s.official_source_url ? (
          <a href={s.official_source_url} target="_blank" rel="noreferrer">
            Official source ↗
          </a>
        ) : (
          <p>No official source link is available.</p>
        )}
        <button className="btn outline" onClick={close}>
          Back to schemes
        </button>
      </section>
    </div>
  );
}
function Explore({ schemes, details, saved, toggle }) {
  const [q, Q] = useState(""),
    [v, V] = useState("all");
  const rows = schemes
    .filter(
      (s) =>
        (!q ||
          `${s.scheme_name} ${s.description || ""}`
            .toLowerCase()
            .includes(q.toLowerCase())) &&
        (v === "all" ||
          (v === "unverified"
            ? s.verification_status !== "verified"
            : s.verification_status === "verified")),
    )
    .sort((a, b) => a.scheme_name.localeCompare(b.scheme_name));
  return (
    <main className="page wrap">
      <div className="page-heading">
        <div>
          <Eyebrow>SCHEME DIRECTORY</Eyebrow>
          <h1>Explore scheme information.</h1>
          <p>
            Search names in the available catalog. We’ll be clear when details
            haven’t been verified.
          </p>
        </div>
        <b className="count">{schemes.length} scheme records</b>
      </div>
      <Notice>
        The workbook has scheme names, not official details. Confirm
        requirements with the department.
      </Notice>
      <div className="filters">
        <label>
          ⌕{" "}
          <input
            value={q}
            onChange={(e) => Q(e.target.value)}
            placeholder="Search scheme name or keyword"
            aria-label="Search schemes"
          />
        </label>
        <select
          value={v}
          onChange={(e) => V(e.target.value)}
          aria-label="Source status"
        >
          <option value="all">All source statuses</option>
          <option value="unverified">Needs verification</option>
          <option value="verified">Source verified</option>
        </select>
        <button
          onClick={() => {
            Q("");
            V("all");
          }}
        >
          Clear filters
        </button>
      </div>
      <div className="result-count">{rows.length} records shown</div>
      {rows.length ? (
        <div className="scheme-grid">
          {rows.map((s) => (
            <SchemeCard
              key={s.id}
              s={s}
              details={details}
              saved={saved.includes(s.id)}
              toggle={toggle}
            />
          ))}
        </div>
      ) : (
        <div className="empty">
          <h3>No scheme names found</h3>
          <p>Try another term or clear the filters.</p>
        </div>
      )}
    </main>
  );
}
const GROUPS = [
    { title: "Personal profile", fields: ["age", "gender", "state"] },
    {
      title: "Education & work",
      fields: ["education_level", "occupation", "student_status"],
    },
    {
      title: "Household & other details",
      fields: [
        "annual_family_income_inr",
        "income_type",
        "residence_type",
        "social_category",
        "disability_status",
        "farmer_status",
      ],
    },
  ],
  LABELS = {
    age: "Age",
    gender: "Gender (optional)",
    state: "State or Union Territory",
    education_level: "Education level",
    occupation: "Occupation",
    student_status: "Student status",
    annual_family_income_inr: "Annual family income (INR)",
    income_type: "Income figure refers to",
    residence_type: "Residence type",
    social_category: "Social category (optional)",
    disability_status: "Disability status (optional)",
    farmer_status: "Farmer status",
  },
  OPTIONS = {
    gender: ["Female", "Male", "Other", "Prefer not to say"],
    education_level: [
      "No formal schooling",
      "School",
      "Undergraduate",
      "Postgraduate",
      "Doctoral",
      "Other",
    ],
    student_status: ["Yes", "No"],
    income_type: ["Family / household", "Individual"],
    residence_type: ["Rural", "Urban"],
    social_category: [
      "General",
      "OBC",
      "SC",
      "ST",
      "Other",
      "Prefer not to say",
    ],
    disability_status: ["Yes", "No", "Prefer not to say"],
    farmer_status: ["Yes", "No"],
  };
function MatchResults({ items, edit, schemes }) {
  const [d, D] = useState(null),
    order = {
      likely_eligible: 0,
      possibly_eligible: 1,
      needs_verification: 2,
      not_currently_matched: 3,
    };
  return (
    <>
      <div className="results-intro">
        <Eyebrow>YOUR PRELIMINARY RESULTS</Eyebrow>
        <h2>{items.length} scheme records to review.</h2>
        <p>
          Unknown requirements remain unknown. This is not a government
          eligibility decision.
        </p>
      </div>
      <Notice />
      {[...items]
        .sort((a, b) => order[a.status] - order[b.status])
        .map((r) => (
          <article className="match-card" key={r.scheme.id}>
            <span className="status">● {r.status.replaceAll("_", " ")}</span>
            <h3>{r.scheme.scheme_name}</h3>
            <p>{r.reason || "This result uses only explicit criteria."}</p>
            <div className="criteria">
              <div>
                <b>✓ Criteria met</b>
                {r.satisfied_criteria.length ? (
                  r.satisfied_criteria.map((x) => <span key={x}>{x}</span>)
                ) : (
                  <span>No verified criteria recorded.</span>
                )}
              </div>
              <div>
                <b>ⓘ Unknown / to confirm</b>
                {r.unknown_criteria.map((x) => (
                  <span key={x}>{x}</span>
                ))}
              </div>
            </div>
            <button className="text-btn" onClick={() => D(r.scheme.id)}>
              View record →
            </button>
          </article>
        ))}
      <div className="results-end">
        <button className="btn outline" onClick={edit}>
          Edit profile
        </button>
        <p>
          No records are currently verified. Confirm current requirements with
          the official department.
        </p>
      </div>
      {d && (
        <Details s={schemes.find((x) => x.id === d)} close={() => D(null)} />
      )}
    </>
  );
}
function ProfileReview({ profile, back, submit, busy, err }) {
  return (
    <section className="review-panel">
      <Eyebrow>REVIEW YOUR PROFILE</Eyebrow>
      <h2>Check these details before matching.</h2>
      <p>
        Your answers are used for this request only. Empty fields remain
        unknown.
      </p>
      <div className="review-grid">
        {Object.entries(LABELS).map(([key, label]) => (
          <div key={key}>
            <small>{label}</small>
            <b>{profile[key] || "Not provided"}</b>
          </div>
        ))}
      </div>
      {err && <div className="error">{err}</div>}
      <div className="form-actions">
        <button className="btn outline" onClick={back}>
          Edit answers
        </button>
        <button className="btn saffron" disabled={busy} onClick={submit}>
          {busy ? "Checking…" : "Submit for matching"} <Arrow />
        </button>
      </div>
    </section>
  );
}
function Eligibility({ schemes }) {
  const [step, S] = useState(0),
    [profile, P] = useState({}),
    [items, I] = useState(null),
    [review, V] = useState(false),
    [err, E] = useState(""),
    [busy, B] = useState(false),
    set = (k, v) => P((p) => ({ ...p, [k]: v })),
    submit = async () => {
      B(true);
      E("");
      try {
        const p = Object.fromEntries(
          Object.entries(profile)
            .map(([k, v]) => [
              k,
              ["age", "annual_family_income_inr"].includes(k) ? Number(v) : v,
            ])
            .filter(([, v]) => v !== "" && v !== undefined),
        );
        I((await api.match(p)).results);
      } catch (e) {
        E(e.message);
      } finally {
        B(false);
      }
    };
  return (
    <main className="page wrap">
      <div className="page-heading">
        <div>
          <Eyebrow>PERSONALIZED DISCOVERY</Eyebrow>
          <h1>Let’s find a place to start.</h1>
          <p>
            Share a few details to compare with scheme records. Optional
            questions can be skipped.
          </p>
        </div>
        <span className="privacy">◇ Not saved</span>
      </div>
      <Notice>
        The catalog lacks verified eligibility criteria. Results will show what
        is missing, not a final decision.
      </Notice>
      {items ? (
        <MatchResults
          items={items}
          edit={() => {
            I(null);
            S(0);
            V(false);
          }}
          schemes={schemes}
        />
      ) : review ? (
        <ProfileReview
          profile={profile}
          back={() => V(false)}
          submit={submit}
          busy={busy}
          err={err}
        />
      ) : (
        <div className="form-layout">
          <aside>
            <b>
              YOUR PROFILE <small>{step + 1} OF 3</small>
            </b>
            <div className="progress">
              <i style={{ width: `${((step + 1) / 3) * 100}%` }} />
            </div>
            {GROUPS.map((x, i) => (
              <div
                key={x.title}
                className={
                  "progress-step " +
                  (i === step ? "current" : i < step ? "done" : "")
                }
              >
                <span>{i < step ? "✓" : i + 1}</span>
                <b>
                  {x.title}
                  <small>
                    {i === step
                      ? "In progress"
                      : i < step
                        ? "Completed"
                        : "Up next"}
                  </small>
                </b>
              </div>
            ))}
            <div className="privacy-box">
              <b>◇ Your profile stays private</b>
              <p>
                Details are sent for this request and are not saved to an
                account.
              </p>
            </div>
          </aside>
          <section className="form-panel">
            <small>SECTION {String(step + 1).padStart(2, "0")}</small>
            <h2>{GROUPS[step].title}</h2>
            <p>
              Missing information will be shown clearly. Optional fields can be
              skipped.
            </p>
            <div className="fields">
              {GROUPS[step].fields.map((k) => (
                <label key={k}>
                  <span>{LABELS[k]}</span>
                  {OPTIONS[k] ? (
                    <select
                      value={profile[k] || ""}
                      onChange={(e) => set(k, e.target.value)}
                    >
                      <option value="">Choose an option</option>
                      {OPTIONS[k].map((x) => (
                        <option key={x}>{x}</option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type={
                        ["age", "annual_family_income_inr"].includes(k)
                          ? "number"
                          : "text"
                      }
                      min="0"
                      max={k === "age" ? 120 : undefined}
                      value={profile[k] || ""}
                      onChange={(e) => set(k, e.target.value)}
                      placeholder={
                        k === "state"
                          ? "Enter State or Union Territory"
                          : k === "age"
                            ? "e.g. 22"
                            : k === "annual_family_income_inr"
                              ? "e.g. 350000"
                              : "Enter your answer"
                      }
                    />
                  )}
                </label>
              ))}
            </div>
            {err && <div className="error">{err}</div>}
            <div className="form-actions">
              {step > 0 ? (
                <button className="btn outline" onClick={() => S(step - 1)}>
                  Back
                </button>
              ) : (
                <span>You can review before matching.</span>
              )}
              {step < 2 ? (
                <button className="btn navy" onClick={() => S(step + 1)}>
                  Continue <Arrow />
                </button>
              ) : (
                <button className="btn navy" onClick={() => V(true)}>
                  Review profile <Arrow />
                </button>
              )}
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
function Assistant({ details }) {
  const [q, Q] = useState(""),
    [r, R] = useState(null),
    [err, E] = useState(""),
    [busy, B] = useState(false),
    ask = async (v = q) => {
      if (!v.trim()) return;
      Q(v);
      B(true);
      E("");
      try {
        R(await api.chat(v));
      } catch (e) {
        E(e.message);
      } finally {
        B(false);
      }
    };
  return (
    <main className="page wrap">
      <div className="page-heading">
        <div>
          <Eyebrow>SCHEME ASSISTANT</Eyebrow>
          <h1>Ask a question. Get a clear answer.</h1>
          <p>
            Answers search scheme names in the workbook. Missing facts won’t be
            invented.
          </p>
        </div>
        <span className="privacy">✳ Dataset search</span>
      </div>
      <div className="assistant-layout">
        <section className="chat">
          <header>
            <b>✳ SchemeSetu Assistant</b>
            <small>● Search available · no AI service configured</small>
          </header>
          <div className="thread">
            <div className="bubble">
              Hi. I can search scheme names in our workbook. The file has no
              verified eligibility details, benefits, or application links, so
              I’ll say when information is missing.
            </div>
            {r && (
              <>
                <div className="bubble user-bubble">{q}</div>
                <div className="bubble">
                  {r.answer}
                  {r.schemes?.map((s) => (
                    <button
                      className="chat-result"
                      key={s.id}
                      onClick={() => details(s.id)}
                    >
                      {s.scheme_name}
                      <span>Needs verification →</span>
                    </button>
                  ))}
                </div>
              </>
            )}
            {busy && <div className="bubble">Searching scheme records…</div>}
          </div>
          <div className="suggestions">
            {[
              "Show scholarships for students",
              "What support is listed for women?",
              "How do I verify a scheme?",
            ].map((x) => (
              <button key={x} onClick={() => ask(x)}>
                {x}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              ask();
            }}
          >
            <input
              value={q}
              onChange={(e) => Q(e.target.value)}
              placeholder="Ask about a scheme or support area…"
              maxLength={1000}
            />
            <button disabled={busy || !q.trim()}>Send ↗</button>
          </form>
          {err && <div className="error">{err}</div>}
          <small className="chat-note">
            Avoid sharing Aadhaar, bank details, or sensitive identifiers.
          </small>
        </section>
        <aside>
          <Eyebrow>WHAT I CAN DO</Eyebrow>
          <h3>Search the catalog</h3>
          <p>Find scheme names by keyword and show available record details.</p>
          <h3>Point out missing information</h3>
          <p>See when eligibility, documents, or official links are absent.</p>
          <h3>Suggest verification</h3>
          <p>
            Use official sources for current requirements and application steps.
          </p>
        </aside>
      </div>
    </main>
  );
}
export default function App() {
  const [page, G] = useState("home"),
    [schemes, S] = useState([]),
    [err, E] = useState(""),
    [detail, D] = useState(null),
    [saved, V] = useState(() => {
      try {
        return JSON.parse(localStorage.getItem("schemesetu-saved") || "[]");
      } catch {
        return [];
      }
    });
  useEffect(() => {
    api
      .schemes({ page_size: 50 })
      .then((d) => S(d.items))
      .catch((e) => E(e.message));
  }, []);
  const toggle = (id) =>
      V((prev) => {
        const n = prev.includes(id)
          ? prev.filter((x) => x !== id)
          : [...prev, id];
        localStorage.setItem("schemesetu-saved", JSON.stringify(n));
        return n;
      }),
    details = async (id) => {
      try {
        D(await api.scheme(id));
      } catch {
        D(schemes.find((x) => x.id === id) || null);
      }
    };
  return (
    <>
      <Header page={page} go={G} />
      {err && (
        <div className="api-warning wrap">
          ⓘ {err}. Start the Flask API to load scheme records.
        </div>
      )}
      {page === "home" ? (
        <Home go={G} count={schemes.length} />
      ) : page === "explore" ? (
        <Explore
          schemes={schemes}
          details={details}
          saved={saved}
          toggle={toggle}
        />
      ) : page === "match" ? (
        <Eligibility schemes={schemes} />
      ) : (
        <Assistant details={details} />
      )}
      <Footer go={G} />
      {detail && <Details s={detail} close={() => D(null)} />}
    </>
  );
}

const API_BASE = import.meta.env.VITE_API_BASE_URL || "";
async function request(path, options = {}) {
  const r = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok)
    throw new Error(
      d?.error?.message || "The service is temporarily unavailable.",
    );
  return d;
}
export const api = {
  schemes: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v));
    return request(`/api/schemes${q.size ? `?${q}` : ""}`);
  },
  scheme: (id) => request(`/api/schemes/${encodeURIComponent(id)}`),
  match: (profile) =>
    request("/api/eligibility/match", {
      method: "POST",
      body: JSON.stringify({ profile }),
    }),
  chat: (question) =>
    request("/api/chat", {
      method: "POST",
      body: JSON.stringify({ question }),
    }),
};

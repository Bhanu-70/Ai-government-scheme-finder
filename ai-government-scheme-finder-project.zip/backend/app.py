﻿from __future__ import annotations
import json, math, os, re
from pathlib import Path
from typing import Any
from flask import Flask, jsonify, request
from flask_cors import CORS

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = Path(os.environ.get('SCHEMES_FILE', str(BASE_DIR / 'data' / 'schemes.json')))
if not DATA_FILE.is_absolute():
    DATA_FILE = (Path(__file__).resolve().parent / DATA_FILE).resolve()
CATALOG_LOAD_ERROR = False
try:
    with DATA_FILE.open(encoding='utf-8') as stream:
        CATALOG = json.load(stream)
    if not isinstance(CATALOG, dict) or not isinstance(CATALOG.get('schemes'), list):
        raise ValueError('Scheme catalog must contain a schemes array')
except (OSError, json.JSONDecodeError, ValueError):
    CATALOG_LOAD_ERROR = True
    CATALOG = {'dataset_metadata': {}, 'schemes': []}
SCHEMES = []
for raw in CATALOG['schemes']:
    if not isinstance(raw, dict) or not raw.get('id') or not raw.get('scheme_name'):
        continue
    item = {**raw}
    item.setdefault('description', None)
    item.setdefault('category', 'Scholarships & fellowships')
    item.setdefault('category_basis', 'inferred_from_title')
    item.setdefault('ministry', None)
    item.setdefault('government_level', None)
    item.setdefault('state_or_ut', None)
    item.setdefault('target_beneficiaries', [])
    item.setdefault('eligibility_rules', {})
    item.setdefault('other_eligibility_conditions', None)
    item.setdefault('mandatory_documents', [])
    item.setdefault('benefits', None)
    item.setdefault('application_steps', [])
    item.setdefault('official_application_url', None)
    item.setdefault('official_source_url', None)
    item.setdefault('source_name', 'User-provided dataset_combined.xlsx')
    item.setdefault('last_verified_date', None)
    item.setdefault('verification_status', 'unverified')
    item.setdefault('verification_note', 'This workbook entry is not an official or verified scheme record.')
    SCHEMES.append(item)

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024
origins = [x.strip() for x in os.environ.get('FLASK_CORS_ORIGINS', 'http://localhost:5173').split(',') if x.strip()]
CORS(app, resources={r'/api/*': {'origins': origins}})
ALLOWED = {'age','state','district','annual_family_income_inr','income_type','education_level','occupation','student_status','residence_type','gender','social_category','disability_status','farmer_status','entrepreneur_status','employment_status','beneficiary_groups'}
LIMITS = {'state':100,'district':100,'income_type':40,'education_level':80,'occupation':100,'residence_type':20,'gender':30,'social_category':50,'disability_status':30,'farmer_status':30,'entrepreneur_status':30,'employment_status':40}

def error(message, status):
    return jsonify({'error': {'message': message}}), status

def validate_profile(payload: Any):
    if not isinstance(payload, dict) or not isinstance(payload.get('profile'), dict):
        return None, 'Request must contain a profile object.'
    profile = payload['profile']
    if set(profile) - ALLOWED:
        return None, 'Profile contains unsupported fields.'
    clean = {}
    for key, value in profile.items():
        if value is None or value == '':
            continue
        if key == 'age':
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 120:
                return None, 'Age must be a whole number from 0 to 120.'
        elif key == 'annual_family_income_inr':
            if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value) or value < 0:
                return None, 'Annual family income must be a non-negative number.'
            value = float(value)
        elif key == 'beneficiary_groups':
            if not isinstance(value, list) or len(value) > 20 or any(not isinstance(x,str) or len(x)>60 for x in value):
                return None, 'Beneficiary groups must be a list of short text values.'
        elif key in LIMITS and (not isinstance(value,str) or len(value)>LIMITS[key]):
            return None, f'{key.replace("_"," ").capitalize()} must be short text.'
        elif key not in {'age','annual_family_income_inr','beneficiary_groups'} and key not in LIMITS and (not isinstance(value,str) or len(value)>100):
            return None, f'{key.replace("_"," ").capitalize()} must be short text.'
        clean[key] = value.strip() if isinstance(value,str) else value
    return clean, None

RULE_PROFILE = {'minimum_age':'age','maximum_age':'age','income_limit_inr':'annual_family_income_inr','income_limit_type':'income_type','applicable_gender':'gender','applicable_states':'state','eligible_occupations':'occupation','eligible_education_levels':'education_level','student_status':'student_status','residence_type':'residence_type','social_categories':'social_category','disability_status':'disability_status','farmer_status':'farmer_status','entrepreneur_status':'entrepreneur_status','employment_status':'employment_status','beneficiary_groups':'beneficiary_groups'}

def compare_rule(key, expected, profile):
    pkey = RULE_PROFILE.get(key)
    if not pkey:
        return 'unknown', f'{key.replace("_"," ").capitalize()} needs a reviewed comparison rule.'
    if pkey not in profile:
        return 'unknown', f'Your {pkey.replace("_"," ")} was not provided.'
    if isinstance(expected, dict) or not isinstance(expected,(int,float,str,list,bool)):
        return 'unknown', f'The recorded {key.replace("_"," ")} condition needs review.'
    actual = profile[pkey]
    try:
        if key == 'minimum_age': passed = actual >= expected
        elif key == 'maximum_age': passed = actual <= expected
        elif key == 'income_limit_inr':
            if profile.get('income_type') != 'Family / household':
                return 'unknown', 'The income limit basis is not confirmed as family or household income.'
            passed = actual <= expected
        elif key == 'income_limit_type': passed = str(actual).casefold() == str(expected).casefold()
        elif key in {'applicable_states','eligible_occupations','eligible_education_levels','social_categories','beneficiary_groups'}:
            ev = expected if isinstance(expected,list) else [expected]
            av = actual if isinstance(actual,list) else [actual]
            passed = any(str(x).casefold() == str(y).casefold() for x in av for y in ev)
        else:
            ev = expected if isinstance(expected,list) else [expected]
            passed = str(actual).casefold() in {str(x).casefold() for x in ev}
    except (TypeError, ValueError):
        return 'unknown', f'The {key.replace("_"," ")} condition could not be interpreted.'
    return ('satisfied' if passed else 'failed', f'Your {pkey.replace("_"," ")} {"meets" if passed else "does not meet"} the recorded {key.replace("_"," ")} condition.')

def match_scheme(scheme, profile):
    rules = scheme.get('eligibility_rules')
    if not isinstance(rules,dict): rules = {}
    satisfied, failed, unknown = [], [], []
    unverified = scheme.get('verification_status') != 'verified'
    if unverified:
        unknown.append('This record has not been verified against an official source; its criteria cannot be used for a decision.')
    else:
        for key, expected in rules.items():
            state, text = compare_rule(key, expected, profile)
            {'satisfied':satisfied,'failed':failed,'unknown':unknown}[state].append(text)
    if not rules: unknown.append('No verified, structured eligibility conditions are available for this record.')
    if unverified: status = 'needs_verification'
    elif failed: status = 'not_currently_matched'
    elif unknown: status = 'possibly_eligible'
    else: status = 'likely_eligible'
    return {'scheme':scheme,'status':status,'satisfied_criteria':satisfied,'failed_mandatory_criteria':failed,'unknown_criteria':unknown,'reason':'This record has not been verified against an official source.' if unverified else None,'preliminary_guidance_only':True}

def search_records(query='', category='', state='', level=''):
    q = query.casefold().strip()
    tokens = [x for x in re.findall(r'[\w-]+', q) if len(x)>2 and x not in {'which','what','where','with','are','any','the','who','can','how','you','your','for','from','about','show','find','tell','please','could','would','this','that','have','does','there','need','want','might','may','suitable','qualify','eligible','eligibility','support','information','details','scheme','schemes','student','students'}]
    tokens = [x[:-1] if x.endswith('s') else x for x in tokens]
    found = []
    for s in SCHEMES:
        haystack = ' '.join(str(s.get(k) or '') for k in ('scheme_name','description','category','ministry','target_beneficiaries')).casefold()
        if q and q not in haystack and not any(t in haystack for t in tokens): continue
        if category and str(s.get('category') or '').casefold() != category.casefold(): continue
        if state and str(s.get('state_or_ut') or '').casefold() not in {'all india','national',state.casefold()}: continue
        if level and str(s.get('government_level') or '').casefold() != level.casefold(): continue
        found.append(s)
    return found

@app.get('/api/health')
def health():
    return jsonify({'status':'degraded' if CATALOG_LOAD_ERROR else 'ok','catalog_available':not CATALOG_LOAD_ERROR,'scheme_records':len(SCHEMES),'catalog_source':CATALOG.get('dataset_metadata',{}).get('dataset_name')})

@app.get('/api/schemes')
def list_schemes():
    try:
        page=max(1,int(request.args.get('page','1')))
        size=min(50,max(1,int(request.args.get('page_size','12'))))
    except ValueError:
        return error('page and page_size must be whole numbers.',400)
    found=search_records(request.args.get('q','')[:200],request.args.get('category','')[:100],request.args.get('state','')[:100],request.args.get('level','')[:40])
    start=(page-1)*size
    return jsonify({'items':found[start:start+size],'total':len(found),'page':page,'page_size':size,'pages':math.ceil(len(found)/size) if found else 0})

@app.get('/api/schemes/<scheme_id>')
def get_scheme(scheme_id):
    item=next((s for s in SCHEMES if s['id']==scheme_id),None)
    return (jsonify(item),200) if item else error('Scheme record not found.',404)

@app.post('/api/eligibility/match')
def eligibility_match():
    profile, issue=validate_profile(request.get_json(silent=True))
    if issue: return error(issue,400)
    return jsonify({'results':[match_scheme(s,profile) for s in SCHEMES],'count':len(SCHEMES),'preliminary_guidance_only':True,'notice':'These records are unverified. This is not a government eligibility decision.'})

@app.post('/api/chat')
def chat():
    payload=request.get_json(silent=True)
    if not isinstance(payload,dict) or not isinstance(payload.get('question'),str): return error('question must be a text field.',400)
    question=payload['question'].strip()
    if not question or len(question)>1000: return error('Question must contain 1 to 1000 characters.',400)
    found=search_records(question)[:5]
    if not found:
        answer='I could not find a matching scheme name in the available workbook. It contains unverified scheme names only, so I cannot confirm eligibility or application details.'
    else:
        names=', '.join(x['scheme_name'] for x in found)
        answer=f'The workbook lists these possibly relevant scheme names: {names}. It does not include verified eligibility rules, benefits, documents, or official links. Confirm current details with the responsible government department.'
    return jsonify({'answer':answer,'schemes':found,'mode':'dataset_search','llm_available':False})

@app.get('/api/categories')
def categories(): return jsonify({'items':sorted({str(x.get('category') or 'Unclassified') for x in SCHEMES})})
@app.get('/api/states')
def states(): return jsonify({'items':sorted({str(x['state_or_ut']) for x in SCHEMES if x.get('state_or_ut')})})
@app.errorhandler(413)
def too_large(_): return error('Request body is too large.',413)
@app.errorhandler(500)
def internal_error(_):
    app.logger.exception('Unhandled server error')
    return error('The service could not complete this request.',500)

if __name__=='__main__':
    host=os.environ.get('FLASK_HOST','127.0.0.1')
    port=int(os.environ.get('FLASK_PORT','5000'))
    debug=os.environ.get('FLASK_DEBUG','false').casefold()=='true'
    app.run(host=host,port=port,debug=debug)

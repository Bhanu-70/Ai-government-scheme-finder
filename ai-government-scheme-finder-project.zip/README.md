﻿# SchemeSetu — AI Government Scheme Finder

A practical starter for transparent government scheme discovery. The current catalog lists ten scheme names extracted from the supplied `dataset_combined.xlsx`; its profile/outcome rows are deliberately not used as eligibility rules.

## Dataset audit

Inspected 2026-10-17: 245,760 rows in the combined workbook (24,576 rows for each of ten names). Columns: `Name`, `Education Qualification`, `Gender`, `Community`, `Religion`, `Exservice-men`, `Disability`, `Sports`, `Annual-Percentage`, `Income`, `India`, `Outcome`. The workbook has no official scheme descriptions, machine-readable eligibility rules, benefits, documents, application steps, or official links. The meaning and provenance of `Outcome`, source attribution, and license are not established. Some scheme filenames refer to 2021–22 or 2022–23. The app ignores outcomes and marks each catalog item unverified. Confirm the source and license before redistribution, then verify current scheme facts against myScheme.gov.in or the responsible ministry/state portal.

## Structure

- `frontend/` — React + Vite interface: home, scheme directory, guided profile form, match explanations, scheme details, and dataset-grounded assistant.
- `backend/app.py` — Flask API, input validation, transparent structured matcher, and search fallback.
- `data/schemes.json` — normalized starter catalog; unavailable facts remain null/empty.

## Local setup

Requires Node.js 20.19+ and Python 3.10+. The Windows Python launcher must be able to find the installed Python runtime.

Backend (PowerShell):

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Frontend in a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Vite forwards `/api` requests to Flask at `127.0.0.1:5000`. CORS defaults to the local Vite origin; set `FLASK_CORS_ORIGINS` to exact permitted frontend origins when needed. The optional Shaders integration uses documented `shaders/react` exports `Shader`, `LinearGradient`, and `CursorTrail`; CSS handles browsers without WebGPU, reduced-motion preferences, or module load failure.

Run backend checks from backend with ..\backend\.venv\Scripts\python.exe -m unittest discover -s ..\tests -v (or python -m unittest discover -s ..\tests -v after activating the environment). Build with cd frontend; npm run build. Static output is in frontend/dist; serve these files and forward /api/* to Flask.

## API contracts

- `GET /api/health` — service state and record count.
- `GET /api/schemes?q=&category=&state=&level=&page=1&page_size=12` — search/filter/paginate.
- `GET /api/schemes/<id>` — a record.
- `POST /api/eligibility/match` — `{ "profile": { "age": 22, "state": "Karnataka" } }`; returns status and satisfied, failed, unknown conditions. A record not marked verified cannot return “likely eligible”.
- `POST /api/chat` — `{ "question": "Which schemes are listed?" }`; searches actual catalog labels and states what the source does not contain. No API key is required.
- `GET /api/categories`, `GET /api/states` — values available in the catalog.

Profiles are processed in memory per request. Do not add Aadhaar, bank credentials, passwords, or other unnecessary identifiers. Keep secrets in environment variables.

## Data rules

Records use fields including `scheme_name`, `description`, `category`, `ministry`, `government_level`, `state_or_ut`, `target_beneficiaries`, `eligibility_rules`, `mandatory_documents`, `benefits`, `application_steps`, official URLs, source, verification date, and status. Missing facts stay null or empty. The initial category is only a title-based browse aid. Add eligibility rules only from reviewed official sources; distinguish household and individual income.

## Five-person collaboration

1. UI/UX: home, accessibility, responsiveness, shader fallback.
2. Forms/results: profile validation, detail view, filters, review flow.
3. Data: licensing, official-source research, normalization, verification dates.
4. Backend: API validation, rule engine, caching when appropriate.
5. Assistant/integration: grounded search, optional LLM adapter, quality checks and deployment.

Coordinate schema changes through `data/schemes.json`, use small feature branches, and review API/schema changes before merging.

## IBM LinuxONE

Deployment-specific instructions must wait until the team confirms the target OS/distribution, IBM Z architecture, installed Python/Node versions, container support, permitted network/ports, and how the jury will access the app. This project does not assume x86, Docker, a database, or public inbound networking.

## Checks

From the repository root, run backend checks with:

```powershell
.\backend\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Build the frontend with `cd frontend; npm run build`.
